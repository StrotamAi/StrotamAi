
// App.js - Main React Code
import React, { useEffect, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

export default function App() {
    const cubeRef = useRef(null);

    useEffect(() => {
        const cube = cubeRef.current;
        let angle = 0;
        const rotateCube = () => {
            angle += 0.01;
            cube.style.transform = `rotateX(${angle}rad) rotateY(${angle}rad)`;
            requestAnimationFrame(rotateCube);
        };
        rotateCube();
    }, []);

    return (
        <Router>
            <div className="container">
                <nav className="navbar">
                    <div className="logo">S̷T尺⚙TΛϺ∀I</div>
                    <ul>
                        <li><Link to="/">Home</Link></li>
                        <li><Link to="/about">About</Link></li>
                        <li><Link to="/services">Services</Link></li>
                        <li><Link to="/contact">Contact</Link></li>
                    </ul>
                </nav>
                <div ref={cubeRef} className="cube"></div>
                <Routes>
                    <Route path="/" element={<div>Home Page</div>} />
                    <Route path="/about" element={<div>About Us</div>} />
                    <Route path="/services" element={<div>Our Services</div>} />
                    <Route path="/contact" element={<div>Contact Us</div>} />
                </Routes>
                <footer className="watermark">© 2024 S̷T尺⚙TΛϺ∀I. All Rights Reserved.</footer>
            </div>
        </Router>
    );
}
